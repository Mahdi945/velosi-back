import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as nodemailer from 'nodemailer';
import * as fs from 'fs';
import * as path from 'path';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { Organisation } from '../entities/organisation.entity';
import { DatabaseConnectionService } from '../common/database-connection.service';

@Injectable()
export class EmailService {
  private readonly logger = new Logger(EmailService.name);
  private transporter: nodemailer.Transporter;
  private organisationTransporters: Map<number, nodemailer.Transporter> = new Map();

  constructor(
    private configService: ConfigService,
    @InjectDataSource('default') private dataSource: DataSource,
    private databaseConnectionService: DatabaseConnectionService,
  ) {
    this.initializeTransporter();
  }

  /**
   * Obtenir l'email expéditeur depuis les variables d'environnement
   */
  private getFromEmail(): string {
    return this.configService.get<string>('SMTP_FROM', this.configService.get<string>('SMTP_USER'));
  }

  /**
   * Obtenir le nom de l'expéditeur depuis les variables d'environnement
   */
  private getFromName(): string {
    return this.configService.get<string>('SMTP_FROM_NAME', 'Shipnology ERP');
  }

  /**
   * Obtenir le chemin du logo de la société (Logimaster/Shipnology)
   */
  private getLogoPath(): string | null {
    const possiblePaths = [
      path.join(process.cwd(), 'assets', 'logimaster.png'),
      path.join(__dirname, '..', '..', 'assets', 'logimaster.png'),
      path.join(__dirname, '..', 'assets', 'logimaster.png'),
      path.join(__dirname, '../../../assets', 'logimaster.png'),
      // Fallback sur logo_shipnology.png si disponible
      path.join(process.cwd(), 'assets', 'logo_shipnology.png'),
      path.join(__dirname, '..', '..', 'assets', 'logo_shipnology.png')
    ];
    
    for (const logoPath of possiblePaths) {
      if (fs.existsSync(logoPath)) {
        this.logger.log(`✅ Logo trouvé à: ${logoPath}`);
        return logoPath;
      }
    }
    
    this.logger.warn('❌ Logo non trouvé dans tous les chemins possibles');
    return null;
  }

  /**
   * Obtenir le logo de la société en base64 (Shipnology/Logimaster)
   */
  private getCompanyLogoBase64(): string {
    try {
      // Chemins possibles pour le logo (essayer logimaster.png et logo_shipnology.png)
      const possiblePaths = [
        path.join(process.cwd(), 'assets', 'logimaster.png'),
        path.join(__dirname, '..', '..', 'assets', 'logimaster.png'),
        path.join(__dirname, '..', 'assets', 'logimaster.png'),
        path.join(__dirname, '../../../assets', 'logimaster.png'),
        // Fallback sur logo_shipnology.png si disponible
        path.join(process.cwd(), 'assets', 'logo_shipnology.png'),
        path.join(__dirname, '..', '..', 'assets', 'logo_shipnology.png')
      ];
      
      for (const logoPath of possiblePaths) {
        this.logger.log(`Tentative de chargement du logo depuis: ${logoPath}`);
        
        if (fs.existsSync(logoPath)) {
          const logoBuffer = fs.readFileSync(logoPath);
          const logoBase64 = logoBuffer.toString('base64');
          const dataUri = `data:image/png;base64,${logoBase64}`;
          this.logger.log(`✅ Logo chargé avec succès depuis: ${logoPath} (${logoBuffer.length} bytes)`);
          this.logger.log(`📊 Base64 length: ${logoBase64.length}, DataURI length: ${dataUri.length}`);
          this.logger.log(`🔍 DataURI prefix: ${dataUri.substring(0, 100)}...`);
          return dataUri;
        } else {
          this.logger.warn(`❌ Logo non trouvé à: ${logoPath}`);
        }
      }
      
      this.logger.error('❌ Aucun logo trouvé dans tous les chemins possibles');
      return '';
    } catch (error) {
      this.logger.error('❌ Erreur lors du chargement du logo:', error);
      return '';
    }
  }

  private initializeTransporter() {
    try {
      // ✅ MODIFICATION: SMTP_USER et SMTP_PASSWORD sont OPTIONNELS en production
      // L'application peut démarrer sans email configuré
      const smtpUser = this.configService.get<string>('SMTP_USER');
      const smtpPass = this.configService.get<string>('SMTP_PASSWORD');
      
      if (!smtpUser || !smtpPass) {
        const warningMsg = '⚠️ SMTP_USER et SMTP_PASSWORD non définis - Service email désactivé';
        this.logger.warn(warningMsg);
        this.transporter = null; // Pas de transporter, donc pas d'envoi d'email
        return; // ✅ Ne pas bloquer le démarrage
      }
      
      const smtpHost = this.configService.get<string>('SMTP_HOST', 'smtp.gmail.com');
      const smtpPort = this.configService.get<number>('SMTP_PORT', 587);
      const smtpSecure = this.configService.get<string>('SMTP_SECURE', 'false') === 'true';
      
      this.transporter = nodemailer.createTransport({
        host: smtpHost,
        port: parseInt(smtpPort.toString()),
        secure: smtpSecure,
        auth: {
          user: smtpUser,
          pass: smtpPass,
        },
        tls: {
          rejectUnauthorized: false,
        },
      });

      this.logger.log(`✅ Service email initialisé avec succès (${smtpUser} via ${smtpHost}:${smtpPort})`);
    } catch (error) {
      this.logger.error('❌ Erreur initialisation service email:', error);
      this.transporter = null; // ✅ Continuer sans email au lieu de bloquer
    }
  }

  /**
   * 🏢 MULTI-TENANT: Obtenir l'organisation depuis la base Shipnology
   */
  private async getOrganisation(organisationId: number): Promise<Organisation | null> {
    try {
      // Se connecter à la base Shipnology pour récupérer l'organisation
      const mainConnection = await this.databaseConnectionService.getMainConnection();
      
      const result = await mainConnection.query(
        `SELECT * FROM organisations WHERE id = $1`,
        [organisationId]
      );
      
      if (result && result.length > 0) {
        return result[0] as Organisation;
      }
      
      this.logger.warn(`⚠️ Organisation avec ID ${organisationId} introuvable`);
      return null;
    } catch (error) {
      this.logger.error(`❌ Erreur lors de la récupération de l'organisation ${organisationId}:`, error);
      return null;
    }
  }

  /**
   * 🏢 MULTI-TENANT: Obtenir ou créer un transporter SMTP pour une organisation
   */
  private async getTransporterForOrganisation(organisationId?: number): Promise<nodemailer.Transporter> {
    // Si pas d'organisationId, utiliser le transporter global
    if (!organisationId) {
      return this.transporter;
    }

    // Vérifier si un transporter existe déjà en cache
    if (this.organisationTransporters.has(organisationId)) {
      return this.organisationTransporters.get(organisationId);
    }

    // Charger l'organisation
    const organisation = await this.getOrganisation(organisationId);
    
    // Si l'organisation n'existe pas ou n'a pas de config SMTP, utiliser le global
    if (!organisation || !organisation.smtp_enabled || !organisation.smtp_host) {
      this.logger.log(`Organisation ${organisationId} utilise le SMTP global`);
      return this.transporter;
    }

    // Créer un transporter personnalisé pour cette organisation
    try {
      const smtpPort = organisation.smtp_port || 587;
      // Pour port 465: secure = true (SSL direct)
      // Pour port 587: secure = false (STARTTLS)
      const isSecure = smtpPort === 465;
      
      this.logger.log(`🔧 Configuration SMTP pour ${organisation.nom}:`, {
        host: organisation.smtp_host,
        port: smtpPort,
        secure: isSecure,
        user: organisation.smtp_user,
        smtp_use_tls: organisation.smtp_use_tls,
        smtp_from_email: organisation.smtp_from_email
      });

      const customTransporter = nodemailer.createTransport({
        host: organisation.smtp_host,
        port: smtpPort,
        secure: isSecure, // true pour SSL (465), false pour TLS/STARTTLS (587)
        auth: {
          user: organisation.smtp_user,
          pass: organisation.smtp_password,
        },
        tls: {
          rejectUnauthorized: false,
          ciphers: 'SSLv3' // Compatible avec Gmail
        },
      });

      // Mettre en cache
      this.organisationTransporters.set(organisationId, customTransporter);
      
      this.logger.log(`✅ Transporter SMTP créé pour organisation ${organisation.nom}: ${organisation.smtp_host}:${smtpPort} (secure: ${isSecure})`);
      
      return customTransporter;
    } catch (error) {
      this.logger.error(`❌ Erreur création transporter pour organisation ${organisationId}:`, error);
      return this.transporter; // Fallback sur le global
    }
  }

  /**
   * 🏢 MULTI-TENANT: Obtenir le logo de l'organisation (ou logo par défaut)
   */
  private async getOrganisationLogoBase64(organisationId?: number): Promise<string> {
    if (!organisationId) {
      return this.getCompanyLogoBase64(); // Logo par défaut
    }

    const organisation = await this.getOrganisation(organisationId);
    
    if (!organisation || !organisation.logo_url) {
      return this.getCompanyLogoBase64(); // Logo par défaut
    }

    try {
      // Le logo_url peut être un chemin local ou une URL
      let logoPath = organisation.logo_url;
      
      // Si c'est un chemin relatif, le transformer en absolu
      if (!logoPath.startsWith('http') && !path.isAbsolute(logoPath)) {
        logoPath = path.join(process.cwd(), 'uploads', logoPath);
      }
      
      // Si c'est un fichier local
      if (!logoPath.startsWith('http') && fs.existsSync(logoPath)) {
        const logoData = fs.readFileSync(logoPath);
        const base64Logo = logoData.toString('base64');
        const mimeType = this.getMimeType(logoPath);
        return `data:${mimeType};base64,${base64Logo}`;
      }
      
      // Si c'est une URL, on retourne l'URL directement
      if (logoPath.startsWith('http')) {
        return logoPath;
      }
      
      // Sinon, logo par défaut
      return this.getCompanyLogoBase64();
    } catch (error) {
      this.logger.error(`❌ Erreur chargement logo organisation ${organisationId}:`, error);
      return this.getCompanyLogoBase64();
    }
  }

  /**
   * Obtenir le MIME type d'un fichier
   */
  private getMimeType(filePath: string): string {
    const ext = path.extname(filePath).toLowerCase();
    const mimeTypes: { [key: string]: string } = {
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.gif': 'image/gif',
      '.svg': 'image/svg+xml',
    };
    return mimeTypes[ext] || 'image/png';
  }

  /**
   * 🏢 MULTI-TENANT: Génère un footer personnalisé pour l'organisation
   */
  private async getEmailFooter(organisationId?: number): Promise<string> {
    if (!organisationId) {
      // Footer par défaut sans organisation
      return `
        <div class="footer" style="
          background-color: #f8f9fa;
          padding: 20px;
          text-align: center;
          border-top: 1px solid #e9ecef;
          margin-top: 30px;
          color: #6c757d;
          font-size: 12px;
          line-height: 1.5;
        ">
          <p style="margin: 0 0 10px 0; font-weight: 500; color: #495057;">
            © ${new Date().getFullYear()} Shipnology ERP - Tous droits réservés
          </p>
          <p style="margin: 0; font-size: 10px; color: #868e96;">
            Cet email a été envoyé automatiquement. Merci de ne pas répondre à cette adresse.
          </p>
        </div>
      `;
    }

    const organisation = await this.getOrganisation(organisationId);
    
    if (!organisation) {
      return this.getEmailFooter(); // Footer par défaut si organisation introuvable
    }

    const nomAffiche = organisation.nom_affichage || organisation.nom;
    const emailServiceTechnique = organisation.email_service_technique || '';
    const siteWeb = organisation.site_web || '';
    
    // Construire la liste des téléphones disponibles (tel1 | tel2 | tel3)
    const phones = [organisation.tel1, organisation.tel2, organisation.tel3].filter(Boolean);
    const telephonesStr = phones.length > 0 ? phones.join(' | ') : '';
    
    return `
      <div class="footer" style="
        background-color: #f8f9fa;
        padding: 25px 20px;
        text-align: center;
        border-top: 1px solid #e9ecef;
        margin-top: 30px;
        color: #6c757d;
        font-size: 12px;
        line-height: 1.6;
      ">
        <p style="margin: 0 0 10px 0; font-weight: 600; color: #2c3e50; font-size: 14px;">
          ${nomAffiche}
        </p>
        ${telephonesStr ? `<p style="margin: 0 0 5px 0; color: #495057;">
          📞 ${telephonesStr}
        </p>` : ''}
        ${siteWeb ? `<p style="margin: 0 0 10px 0; color: #495057;">
          🌐 <a href="${siteWeb.startsWith('http') ? siteWeb : 'https://' + siteWeb}" target="_blank" style="color: #5e72e4; text-decoration: none;">${siteWeb}</a>
        </p>` : ''}
        ${emailServiceTechnique ? `<p style="margin: 10px 0 5px 0; color: #495057; font-size: 13px;">
          💬 <strong>Besoin d'aide?</strong> Contactez-nous: <a href="mailto:${emailServiceTechnique}" style="color: #5e72e4; text-decoration: none; font-weight: 600;">${emailServiceTechnique}</a>
        </p>` : ''}
        <hr style="border: none; border-top: 1px solid #dee2e6; margin: 15px 0;" />
        <p style="margin: 0 0 5px 0; font-size: 11px; color: #6c757d;">
          Propulsé par <strong style="color: #5e72e4;">Shipnology ERP</strong>
        </p>
        <p style="margin: 0; font-size: 10px; color: #868e96;">
          © ${new Date().getFullYear()} - Tous droits réservés
        </p>
        <p style="margin: 5px 0 0 0; font-size: 10px; color: #adb5bd;">
          Cet email a été envoyé automatiquement. Merci de ne pas répondre à cette adresse.
        </p>
      </div>
    `;
  }

  /**
   * Génère un footer simple et unifié pour tous les emails (DEPRECATED - Utiliser getEmailFooter)
   * @deprecated Utiliser getEmailFooter(organisationId) pour un footer personnalisé
   */
  private getSimpleEmailFooter(): string {
    return `
      <div class="footer" style="
        background-color: #f8f9fa;
        padding: 20px;
        text-align: center;
        border-top: 1px solid #e9ecef;
        margin-top: 30px;
        color: #6c757d;
        font-size: 12px;
        line-height: 1.5;
      ">
        <p style="margin: 0 0 10px 0; font-weight: 500; color: #495057;">
          © ${new Date().getFullYear()} Velosi - Tous droits réservés
        </p>
        <p style="margin: 0 0 5px 0; font-size: 11px; color: #6c757d;">
          Propulsé par <strong>Shipnology</strong>
        </p>
        <p style="margin: 0; font-size: 10px; color: #868e96;">
          Cet email a été envoyé automatiquement. Merci de ne pas répondre à cette adresse.
        </p>
      </div>
    `;
  }

  /**
   * Méthode générique pour envoyer un email
   */
  async sendEmail(to: string, subject: string, htmlContent: string): Promise<boolean> {
    try {
      // ✅ Vérifier si le transporter est configuré
      if (!this.transporter) {
        const errorMsg = `⚠️ Impossible d'envoyer l'email à ${to}: Service email non configuré (SMTP_USER/SMTP_PASSWORD manquants)`;
        this.logger.error(errorMsg);
        throw new Error(errorMsg);
      }
      
      this.logger.log(`📧 Envoi d'email à ${to} - Sujet: ${subject}`);
      
      const mailOptions = {
        from: this.configService.get('SMTP_FROM', 'noreply@velosi.com'),
        to,
        subject,
        html: htmlContent,
      };

      const result = await this.transporter.sendMail(mailOptions);
      this.logger.log(`✅ Email envoyé avec succès à ${to} - ID: ${result.messageId}`);
      return true;
    } catch (error) {
      this.logger.error(`❌ Erreur lors de l'envoi de l'email à ${to}: ${error.message}`);
      throw error;
    }
  }
  
  /**
   * Envoyer un email avec le logo en pièce jointe
   */
  async sendEmailWithLogo(to: string, subject: string, htmlContent: string): Promise<boolean> {
    try {
      // ✅ Vérifier si le transporter est configuré
      if (!this.transporter) {
        const errorMsg = `⚠️ Impossible d'envoyer l'email à ${to}: Service email non configuré (SMTP_USER/SMTP_PASSWORD manquants)`;
        this.logger.error(errorMsg);
        throw new Error(errorMsg);
      }
      
      this.logger.log(`📧 Envoi d'email avec logo à ${to} - Sujet: ${subject}`);
      
      // Préparer l'attachment du logo
      const logoPath = this.getLogoPath();
      const attachments = [];
      
      if (logoPath && fs.existsSync(logoPath)) {
        attachments.push({
          filename: 'logo_velosi.png',
          path: logoPath,
          cid: 'logo_velosi' // Content-ID pour référencer dans le HTML avec cid:logo_velosi
        });
        this.logger.log(`✅ Logo attaché depuis: ${logoPath}`);
      } else {
        this.logger.warn(`⚠️ Logo non trouvé, email envoyé sans logo`);
      }
      
      const mailOptions = {
        from: {
          name: this.getFromName(),
          address: this.configService.get('SMTP_FROM', 'noreply@velosi.com')
        },
        to,
        subject,
        html: htmlContent,
        attachments: attachments
      };

      const result = await this.transporter.sendMail(mailOptions);
      this.logger.log(`✅ Email envoyé avec succès à ${to} - ID: ${result.messageId}`);
      return true;
    } catch (error) {
      this.logger.error(`❌ Erreur lors de l'envoi de l'email à ${to}: ${error.message}`);
      throw error;
    }
  }

  /**
   * Envoyer un email avec le logo Logimaster (Shipnology)
   */
  async sendEmailWithLogimasterLogo(to: string, subject: string, htmlContent: string): Promise<boolean> {
    try {
      // ✅ Vérifier si le transporter est configuré
      if (!this.transporter) {
        const errorMsg = `⚠️ Impossible d'envoyer l'email à ${to}: Service email non configuré (SMTP_USER/SMTP_PASSWORD manquants)`;
        this.logger.error(errorMsg);
        throw new Error(errorMsg);
      }
      
      this.logger.log(`📧 Envoi d'email avec logo Logimaster à ${to} - Sujet: ${subject}`);
      
      // Préparer l'attachment du logo Logimaster
      const possiblePaths = [
        path.join(process.cwd(), 'assets', 'logimaster.png'),
        path.join(__dirname, '..', '..', 'assets', 'logimaster.png'),
        path.join(__dirname, '..', 'assets', 'logimaster.png'),
        path.join(__dirname, '../../../assets', 'logimaster.png')
      ];
      
      const attachments = [];
      let logoFound = false;
      
      for (const logoPath of possiblePaths) {
        if (fs.existsSync(logoPath)) {
          attachments.push({
            filename: 'logimaster.png',
            path: logoPath,
            cid: 'logo_logimaster' // Content-ID pour référencer dans le HTML avec cid:logo_logimaster
          });
          this.logger.log(`✅ Logo Logimaster attaché depuis: ${logoPath}`);
          logoFound = true;
          break;
        }
      }
      
      if (!logoFound) {
        this.logger.warn(`⚠️ Logo Logimaster non trouvé dans les chemins possibles, email envoyé sans logo`);
      }
      
      this.logger.log(`📎 Nombre d'attachments pour cet email: ${attachments.length}`);
      
      const mailOptions = {
        from: {
          name: this.getFromName(),
          address: this.configService.get('SMTP_FROM', 'noreply@velosi.com')
        },
        to,
        subject,
        html: htmlContent,
        attachments: attachments
      };

      const result = await this.transporter.sendMail(mailOptions);
      this.logger.log(`✅ Email envoyé avec succès à ${to} - ID: ${result.messageId}`);
      return true;
    } catch (error) {
      this.logger.error(`❌ Erreur lors de l'envoi de l'email à ${to}: ${error.message}`);
      throw error;
    }
  }

  /**
   * 🏢 MULTI-TENANT: Envoyer un code OTP par email
   * @param email - Email du destinataire
   * @param otpCode - Code OTP à 6 chiffres
   * @param userName - Nom de l'utilisateur (optionnel)
   * @param organisationId - ID de l'organisation (optionnel, utilise config globale si absent)
   */
  async sendOtpEmail(email: string, otpCode: string, userName?: string, organisationId?: number): Promise<boolean> {
    try {
      this.logger.log(`📧 Envoi OTP à ${email} (organisationId: ${organisationId || 'Global'})`);
      
      // Obtenir le transporter approprié (organisation ou global)
      const transporter = await this.getTransporterForOrganisation(organisationId);
      
      if (!transporter) {
        this.logger.warn(`⚠️ Impossible d'envoyer l'OTP à ${email}: Service email non configuré`);
        return false;
      }
      
      // Charger l'organisation si ID fourni
      const organisation = organisationId ? await this.getOrganisation(organisationId) : null;
      
      if (organisation) {
        this.logger.log(`🏢 Organisation: ${organisation.nom}`, {
          smtp_enabled: organisation.smtp_enabled,
          smtp_host: organisation.smtp_host,
          smtp_port: organisation.smtp_port,
          smtp_user: organisation.smtp_user,
          smtp_from_email: organisation.smtp_from_email
        });
      }
      
      // Obtenir le logo de l'organisation
      const logoBase64 = await this.getOrganisationLogoBase64(organisationId);
      
      // Obtenir le footer personnalisé
      const footer = await this.getEmailFooter(organisationId);
      
      // Générer le template avec les infos de l'organisation
      const htmlTemplate = await this.getOtpEmailTemplate(otpCode, userName, organisation, footer, logoBase64);
      
      // Déterminer l'expéditeur
      const fromName = organisation?.smtp_from_name || organisation?.nom_affichage || organisation?.nom || this.getFromName();
      const fromEmail = organisation?.smtp_from_email || this.getFromEmail();
      
      this.logger.log(`📨 Expéditeur: ${fromName} <${fromEmail}>`);
      
      // Préparer les pièces jointes
      const attachments = [];
      
      // Ajouter le logo comme pièce jointe avec CID
      if (organisation?.logo_url && !organisation.logo_url.startsWith('http')) {
        // Logo de l'organisation - nettoyer le chemin
        let logoRelativePath = organisation.logo_url;
        // Supprimer le préfixe /uploads/ ou uploads/ ou / (pour éviter uploads/uploads/ ou chemins absolus)
        if (logoRelativePath.startsWith('/uploads/')) {
          logoRelativePath = logoRelativePath.substring('/uploads/'.length);
        } else if (logoRelativePath.startsWith('uploads/')) {
          logoRelativePath = logoRelativePath.substring('uploads/'.length);
        } else if (logoRelativePath.startsWith('/')) {
          logoRelativePath = logoRelativePath.substring(1);
        }
        // Toujours pointer vers le dossier uploads du projet
        const logoPath = path.join(process.cwd(), 'uploads', logoRelativePath.replace(/\\/g, '/'));
        this.logger.log(`🔍 Recherche logo organisation: ${organisation.logo_url} -> ${logoPath}`);
        if (fs.existsSync(logoPath)) {
          this.logger.log(`📎 Ajout du logo organisation comme pièce jointe: ${logoPath}`);
          attachments.push({
            filename: path.basename(logoPath),
            path: logoPath,
            cid: 'logo_organisation'
          });
        } else {
          this.logger.warn(`⚠️ Logo organisation introuvable: ${logoPath}`);
          // Fallback sur le logo par défaut
          const defaultLogoPath = this.getLogoPath();
          if (defaultLogoPath && fs.existsSync(defaultLogoPath)) {
            this.logger.log(`📎 Utilisation du logo par défaut: ${defaultLogoPath}`);
            attachments.push({
              filename: path.basename(defaultLogoPath),
              path: defaultLogoPath,
              cid: 'logo_organisation' // Garder le même CID
            });
          }
        }
      } else if (!organisation || !organisation.logo_url) {
        // Logo par défaut Shipnology/Logimaster
        const logoPath = this.getLogoPath();
        if (logoPath && fs.existsSync(logoPath)) {
          this.logger.log(`📎 Ajout du logo par défaut comme pièce jointe: ${logoPath}`);
          attachments.push({
            filename: path.basename(logoPath),
            path: logoPath,
            cid: 'logo_shipnology'
          });
        } else {
          this.logger.warn(`⚠️ Logo par défaut introuvable`);
        }
      }
      
      const mailOptions = {
        from: {
          name: `${fromName} - Récupération de compte`,
          address: fromEmail
        },
        to: email,
        subject: `🔐 Code de récupération ${fromName}`,
        html: htmlTemplate,
        text: `Votre code de récupération est: ${otpCode}. Ce code expire dans 10 minutes.`,
        attachments: attachments
      };

      const result = await transporter.sendMail(mailOptions);
      this.logger.log(`✅ OTP envoyé avec succès à ${email} (Org: ${organisation?.nom || 'Global'}) - ID: ${result.messageId}`);
      return true;
    } catch (error) {
      this.logger.error(`❌ Erreur lors de l'envoi de l'OTP à ${email}:`, error);
      return false;
    }
  }

  /**
   * Envoyer notification de réinitialisation réussie
   */
  async sendPasswordResetSuccessEmail(email: string, userName?: string): Promise<boolean> {
    try {
      // ✅ Vérifier si le transporter est configuré
      if (!this.transporter) {
        this.logger.warn(`⚠️ Impossible d'envoyer la confirmation à ${email}: Service email non configuré`);
        return false;
      }
      
      const htmlTemplate = this.getSuccessEmailTemplate(userName);
      
      // Préparer l'attachment du logo
      const logoPath = this.getLogoPath();
      const attachments = [];
      
      if (logoPath && fs.existsSync(logoPath)) {
        attachments.push({
          filename: path.basename(logoPath),
          path: logoPath,
          cid: 'logo_shipnology'
        });
      }
      
      const mailOptions = {
        from: {
          name: `${this.getFromName()} - Sécurité`,
          address: this.getFromEmail()
        },
        to: email,
        subject: '✅ Mot de passe réinitialisé - Velosi ERP',
        html: htmlTemplate,
        text: `Votre mot de passe Velosi ERP a été réinitialisé avec succès.`,
        attachments: attachments
      };

      const result = await this.transporter.sendMail(mailOptions);
      this.logger.log(`Email confirmation envoyé avec succès à ${email} - ID: ${result.messageId}`);
      return true;
    } catch (error) {
      this.logger.error(`Erreur envoi email confirmation à ${email}:`, error);
      return false;
    }
  }

  /**
   * Envoyer notification de réinitialisation de mot de passe par administrateur
   */
  async sendPasswordResetByAdminEmail(
    email: string, 
    userName: string, 
    userType: 'personnel' | 'client', 
    newPassword: string,
    adminName?: string
  ): Promise<boolean> {
    try {
      if (!this.transporter) {
        this.logger.warn(`⚠️ Impossible d'envoyer la notification à ${email}: Service email non configuré`);
        return false;
      }

      const htmlTemplate = this.getAdminResetEmailTemplate(userName, userType, newPassword, adminName);
      
      const logoPath = this.getLogoPath();
      const attachments = [];
      
      if (logoPath && fs.existsSync(logoPath)) {
        attachments.push({
          filename: path.basename(logoPath),
          path: logoPath,
          cid: 'logo_shipnology'
        });
      }
      
      const mailOptions = {
        from: {
          name: `${this.getFromName()} - Sécurité`,
          address: this.getFromEmail()
        },
        to: email,
        subject: '🔐 Réinitialisation de votre mot de passe - Shipnology ERP',
        html: htmlTemplate,
        text: `Votre mot de passe Velosi ERP a été réinitialisé par un administrateur. Votre nouveau mot de passe temporaire est: ${newPassword}. Veuillez le changer lors de votre première connexion.`,
        attachments: attachments
      };

      const result = await this.transporter.sendMail(mailOptions);
      this.logger.log(`✅ Email notification admin reset envoyé à ${email} - ID: ${result.messageId}`);
      return true;
    } catch (error) {
      this.logger.error(`❌ Erreur envoi email notification admin reset à ${email}:`, error);
      return false;
    }
  }

  /**
   * 🏢 MULTI-TENANT: Template HTML pour l'email OTP
   */
  private async getOtpEmailTemplate(
    otpCode: string, 
    userName?: string, 
    organisation?: Organisation | null,
    footer?: string,
    logoBase64?: string
  ): Promise<string> {
    const displayName = userName || 'Utilisateur';
    const orgName = organisation?.nom_affichage || organisation?.nom || 'Shipnology ERP';
    const logoCid = organisation?.logo_url ? 'logo_organisation' : 'logo_shipnology';
    const finalFooter = footer || await this.getEmailFooter(organisation?.id);
    
    return `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Code de récupération ${orgName}</title>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
            
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Inter', Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                padding: 20px;
            }
            
            .container {
                max-width: 600px;
                margin: 0 auto;
                background: #ffffff;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                overflow: hidden;
            }
            
            .header {
                background: linear-gradient(135deg, #5e72e4 0%, #825ee4 100%);
                padding: 30px;
                text-align: center;
                color: white;
                position: relative;
            }
            
            .header::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" fill="rgba(255,255,255,0.1)"><polygon points="0,100 0,0 500,100 1000,0 1000,100"/></svg>');
                background-size: cover;
            }
            
            .logo-fallback {
                width: 120px;
                height: 60px;
                background: #fff;
                border-radius: 12px;
                margin: 0 auto 20px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: 700;
                font-size: 18px;
                color: #5e72e4;
                box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            }
            
            .header h1 {
                font-size: 28px;
                font-weight: 600;
                margin-bottom: 10px;
                position: relative;
                z-index: 2;
            }
            
            .header p {
                font-size: 16px;
                opacity: 0.9;
                position: relative;
                z-index: 2;
            }
            
            .content {
                padding: 40px 30px;
            }
            
            .greeting {
                font-size: 18px;
                margin-bottom: 25px;
                color: #2d3748;
            }
            
            .otp-section {
                text-align: center;
                margin: 35px 0;
                padding: 30px;
                background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%);
                border-radius: 16px;
                border: 2px solid #e2e8f0;
            }
            
            .otp-label {
                font-size: 16px;
                color: #4a5568;
                margin-bottom: 15px;
                font-weight: 500;
            }
            
            .otp-code {
                display: inline-block;
                font-size: 36px;
                font-weight: 700;
                color: #5e72e4;
                background: #fff;
                padding: 20px 40px;
                border-radius: 12px;
                letter-spacing: 8px;
                border: 3px solid #5e72e4;
                box-shadow: 0 8px 25px rgba(94, 114, 228, 0.2);
                animation: pulse 2s infinite;
                word-break: break-all;
                max-width: 100%;
            }
            
            @media (max-width: 600px) {
                .container {
                    margin: 0;
                    border-radius: 0;
                }
                
                .otp-code {
                    font-size: 28px;
                    padding: 15px 20px;
                    letter-spacing: 4px;
                    word-break: break-all;
                }
                
                .otp-section {
                    padding: 20px 15px;
                    margin: 25px 0;
                }
                
                .content {
                    padding: 30px 20px;
                }
                
                .header {
                    padding: 25px 20px;
                }
                
                .header h1 {
                    font-size: 24px;
                }
                
                .instructions, .security-warning {
                    padding: 15px;
                }
            }
            
            @keyframes pulse {
                0% { transform: scale(1); }
                50% { transform: scale(1.05); }
                100% { transform: scale(1); }
            }
            
            .timer-info {
                margin-top: 20px;
                font-size: 14px;
                color: #e53e3e;
                font-weight: 500;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 8px;
            }
            
            .timer-icon {
                width: 16px;
                height: 16px;
                border-radius: 50%;
                background: #e53e3e;
                color: white;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 10px;
            }
            
            .instructions {
                background: #f0fff4;
                border: 1px solid #9ae6b4;
                border-radius: 12px;
                padding: 20px;
                margin: 25px 0;
            }
            
            .instructions h3 {
                color: #22543d;
                font-size: 16px;
                margin-bottom: 12px;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            
            .instructions ul {
                margin-left: 20px;
                color: #2d3748;
            }
            
            .instructions li {
                margin-bottom: 8px;
                font-size: 14px;
            }
            
            .security-warning {
                background: #fef5e7;
                border: 1px solid #f6ad55;
                border-radius: 12px;
                padding: 20px;
                margin: 25px 0;
            }
            
            .security-warning h3 {
                color: #c05621;
                font-size: 16px;
                margin-bottom: 12px;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            
            .security-warning p {
                color: #2d3748;
                font-size: 14px;
                margin-bottom: 8px;
            }
            
            .footer {
                background: #f8f9fa;
                padding: 30px;
                text-align: center;
                border-top: 1px solid #e2e8f0;
            }
            
            .footer p {
                color: #6c757d;
                font-size: 12px;
                margin-bottom: 5px;
            }
            
            .contact-info {
                margin-top: 20px;
                padding: 15px;
                background: #fff;
                border-radius: 8px;
                border: 1px solid #e2e8f0;
            }
            
            .contact-info h4 {
                color: #2d3748;
                font-size: 14px;
                margin-bottom: 8px;
            }
            
            .contact-info p {
                color: #4a5568;
                font-size: 12px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <img src="cid:${logoCid}" alt="Logo ${orgName}" style="max-width:180px; max-height:80px; display:block; margin:0 auto 18px;" />
                <h1>🔐 Code de Récupération</h1>
                <p>Récupération sécurisée de votre compte</p>
            </div>
            
            <div class="content">
                <div class="greeting">
                    Bonjour <strong>${displayName}</strong>,
                </div>
                
                <p>Vous avez demandé la récupération de votre mot de passe pour votre compte <strong>${orgName}</strong>.</p>
                
                <div class="otp-section">
                    <div class="otp-label">Votre code de vérification :</div>
                    <div class="otp-code">${otpCode}</div>
                    <div class="timer-info">
                         
                        Ce code expire dans 10 minutes
                    </div>
                </div>
                
                <div class="instructions">
                    <h3>📋 Instructions :</h3>
                    <ul>
                        <li>Saisissez ce code dans la page de vérification</li>
                        <li>Le code est valide pendant <strong>10 minutes</strong></li>
                        <li>Après vérification, vous pourrez créer un nouveau mot de passe</li>
                        <li>Ce code ne peut être utilisé qu'une seule fois</li>
                    </ul>
                </div>
                
                <div class="security-warning">
                    <h3>🛡️ Sécurité :</h3>
                    <p><strong>Ne partagez jamais ce code</strong> avec qui que ce soit.</p>
                    <p>Si vous n'avez pas demandé cette récupération, ignorez cet email et contactez immédiatement votre administrateur.</p>
                    <p>${orgName} ne vous demandera jamais votre code par téléphone ou email.</p>
                </div>
                
                <p style="margin-top: 30px; color: #4a5568;">
                    Si vous avez des questions, notre équipe technique est à votre disposition.
                </p>
            </div>
            
            ${finalFooter}
        </div>
    </body>
    </html>
    `;
  }

  /**
   * Template HTML pour la confirmation de réinitialisation
   */
  private getSuccessEmailTemplate(userName?: string): string {
    const displayName = userName || 'Utilisateur';
    
    return `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Mot de passe réinitialisé - Velosi ERP</title>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
            
            body {
                font-family: 'Inter', Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
                padding: 20px;
                margin: 0;
            }
            
            .container {
                max-width: 600px;
                margin: 0 auto;
                background: #ffffff;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                overflow: hidden;
            }
            
            .header {
                background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
                padding: 30px;
                text-align: center;
                color: white;
            }
            
            .logo-fallback {
                width: 120px;
                height: 60px;
                background: #fff;
                border-radius: 12px;
                margin: 0 auto 20px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: 700;
                font-size: 18px;
                color: #48bb78;
                box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            }
            
            .content {
                padding: 40px 30px;
                text-align: center;
            }
            
            .success-icon {
                width: 80px;
                height: 80px;
                background: #48bb78;
                border-radius: 50%;
                margin: 0 auto 30px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 40px;
                color: white;
                animation: bounce 1s infinite alternate;
            }
            
            @keyframes bounce {
                from { transform: translateY(0px); }
                to { transform: translateY(-10px); }
            }
            
            .footer {
                background: #f8f9fa;
                padding: 20px;
                text-align: center;
                font-size: 12px;
                color: #6c757d;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <img src="cid:logo_velosi" alt="Logo Velosi" width="200" height="auto" />
                <h1>✅ Réinitialisation Réussie</h1>
            </div>
            
            <div class="content">
                
                <h2>Mot de passe réinitialisé avec succès !</h2>
                <p>Bonjour <strong>${displayName}</strong>,</p>
                <p>Votre mot de passe Velosi ERP a été réinitialisé avec succès le ${new Date().toLocaleDateString('fr-FR')} à ${new Date().toLocaleTimeString('fr-FR')}.</p>
                <p>Vous pouvez maintenant vous connecter avec votre nouveau mot de passe.</p>
            </div>
            
            ${this.getSimpleEmailFooter()}
        </div>
    </body>
    </html>
    `;
  }

  /**
   * Template HTML pour notification de réinitialisation par admin
   */
  private getAdminResetEmailTemplate(userName: string, userType: 'personnel' | 'client', newPassword: string, adminName?: string): string {
    const userTypeLabel = userType === 'personnel' ? 'Personnel' : 'Client';
    const adminInfo = adminName ? `par <strong>${adminName}</strong>` : 'par un administrateur';
    
    return `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Réinitialisation Mot de Passe - Velosi ERP</title>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
            
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Inter', Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                padding: 20px;
            }
            
            .container {
                max-width: 600px;
                margin: 0 auto;
                background-color: #ffffff;
                border-radius: 12px;
                overflow: hidden;
                box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
            }
            
            .header {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                padding: 40px 30px;
                text-align: center;
                position: relative;
            }
            
            .logo {
                max-width: 180px;
                height: auto;
                margin-bottom: 15px;
            }
            
            .header h1 {
                color: #ffffff;
                font-size: 28px;
                font-weight: 700;
                margin: 0;
                text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }
            
            .header p {
                color: rgba(255, 255, 255, 0.9);
                font-size: 14px;
                margin: 5px 0 0 0;
            }
            
            .content {
                padding: 40px 30px;
            }
            
            .title {
                color: #f59e0b;
                font-size: 24px;
                font-weight: 600;
                margin-bottom: 20px;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .greeting {
                font-size: 16px;
                color: #4b5563;
                margin-bottom: 25px;
            }
            
            .alert-box {
                background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
                border-left: 4px solid #f59e0b;
                padding: 20px;
                margin: 25px 0;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(245, 158, 11, 0.1);
            }
            
            .alert-box p {
                color: #92400e;
                font-weight: 500;
                margin: 0;
            }
            
            .admin-info-box {
                background: linear-gradient(135deg, #e0e7ff 0%, #c7d2fe 100%);
                border-left: 4px solid #6366f1;
                padding: 15px 20px;
                margin: 20px 0;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(99, 102, 241, 0.1);
            }
            
            .admin-info-box p {
                color: #312e81;
                font-size: 14px;
                margin: 0;
            }
            
            .password-box {
                background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
                border: 2px solid #3b82f6;
                padding: 25px;
                margin: 25px 0;
                border-radius: 8px;
                text-align: center;
                box-shadow: 0 2px 8px rgba(59, 130, 246, 0.1);
            }
            
            .password-box h3 {
                color: #1e40af;
                font-size: 16px;
                margin-bottom: 15px;
                font-weight: 600;
            }
            
            .password-code {
                background-color: #ffffff;
                color: #1e3a8a;
                font-size: 24px;
                font-weight: 700;
                padding: 15px 25px;
                border-radius: 8px;
                letter-spacing: 2px;
                font-family: 'Courier New', monospace;
                display: inline-block;
                border: 2px dashed #3b82f6;
                margin: 10px 0;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            }
            
            .instructions {
                background-color: #f9fafb;
                padding: 25px;
                margin: 25px 0;
                border-radius: 8px;
                border: 1px solid #e5e7eb;
            }
            
            .instructions h3 {
                color: #1e40af;
                font-size: 18px;
                margin-bottom: 15px;
                font-weight: 600;
            }
            
            .instructions ol {
                margin-left: 20px;
                line-height: 1.8;
                color: #4b5563;
            }
            
            .instructions li {
                margin-bottom: 10px;
            }
            
            .security-warning {
                background-color: #fef2f2;
                border-left: 4px solid #dc2626;
                padding: 20px;
                margin: 25px 0;
                border-radius: 8px;
            }
            
            .security-warning h3 {
                color: #dc2626;
                font-size: 16px;
                margin-bottom: 12px;
                font-weight: 600;
            }
            
            .security-warning ul {
                margin-left: 20px;
                line-height: 1.8;
                color: #7f1d1d;
            }
            
            .info-footer {
                margin-top: 30px;
                padding-top: 20px;
                border-top: 2px solid #e5e7eb;
                color: #6b7280;
                font-size: 14px;
            }
            
            .footer {
                background-color: #f9fafb;
                padding: 30px;
                text-align: center;
                color: #6b7280;
                font-size: 13px;
                line-height: 1.6;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <img src="cid:logo_velosi" alt="Velosi" class="logo" />
                <h1>🔐 Velosi ERP</h1>
                <p>Système de Gestion d'Entreprise</p>
            </div>
            
            <div class="content">
                <h2 class="title">
                    🔐 Réinitialisation de Mot de Passe
                </h2>
                
                <p class="greeting">Bonjour <strong>${userName}</strong>,</p>
                
                <div class="alert-box">
                    <p>
                        <strong>⚠️ Important:</strong> Votre mot de passe a été réinitialisé ${adminInfo}.
                    </p>
                </div>
                
                ${adminName ? `
                <div class="admin-info-box">
                    <p>
                        👤 <strong>Action effectuée par:</strong> ${adminName}<br>
                        📅 <strong>Date:</strong> ${new Date().toLocaleString('fr-FR', {
                          dateStyle: 'full',
                          timeStyle: 'short'
                        })}
                    </p>
                </div>
                ` : ''}
                
                <p style="margin: 20px 0;">Pour des raisons de sécurité, votre mot de passe Velosi ERP a été réinitialisé.</p>
                
                <div class="password-box">
                    <h3>🔑 Votre Nouveau Mot de Passe Temporaire</h3>
                    <div class="password-code">${newPassword}</div>
                    <p style="color: #1e40af; font-size: 13px; margin-top: 10px;">
                        ⚠️ Ce mot de passe est temporaire et doit être changé lors de votre première connexion
                    </p>
                </div>
                
                <div class="instructions">
                    <h3>📋 Prochaines Étapes</h3>
                    <ol>
                        <li><strong>Copiez</strong> le mot de passe temporaire ci-dessus</li>
                        <li><strong>Connectez-vous</strong> à Velosi ERP avec ce mot de passe</li>
                        <li><strong>Changez immédiatement</strong> votre mot de passe lors de votre première connexion</li>
                        <li><strong>Choisissez</strong> un mot de passe fort et unique (minimum 8 caractères avec majuscules, minuscules, chiffres et symboles)</li>
                    </ol>
                </div>
                
                <div class="security-warning">
                    <h3>🛡️ Recommandations de Sécurité</h3>
                    <ul>
                        <li>Ne partagez jamais votre mot de passe avec qui que ce soit</li>
                        <li>N'utilisez pas ce mot de passe temporaire pour d'autres services</li>
                        <li>Changez votre mot de passe régulièrement</li>
                        <li>Si vous n'avez pas demandé cette réinitialisation, contactez immédiatement votre administrateur</li>
                    </ul>
                </div>
                
                <div class="info-footer">
                    <p style="margin: 0;">
                        <strong>Type de compte:</strong> ${userTypeLabel}
                    </p>
                </div>
            </div>
            
            <div class="footer">
                <p style="margin: 0 0 10px 0;">
                    <strong>Velosi ERP</strong> - Système de Gestion d'Entreprise
                </p>
                <p style="margin: 0; color: #9ca3af;">
                    Cet email a été envoyé automatiquement, merci de ne pas y répondre.<br>
                    Pour toute question, contactez votre administrateur système.
                </p>
            </div>
        </div>
    </body>
    </html>
    `;
  }

  /**
   * Vérifier la connexion email
   */
  async verifyConnection(): Promise<boolean> {
    try {
      // ✅ Vérifier si le transporter est configuré
      if (!this.transporter) {
        this.logger.warn('⚠️ Service email non configuré');
        return false;
      }
      
      await this.transporter.verify();
      this.logger.log('Connexion email vérifiée avec succès');
      return true;
    } catch (error) {
      this.logger.error('Erreur vérification connexion email:', error);
      return false;
    }
  }

  /**
   * Méthode alternative: utiliser l'URL publique du logo
   */
  async sendOtpEmailWithPublicLogo(email: string, otpCode: string, userName?: string): Promise<boolean> {
    try {
      const htmlTemplate = this.getOtpEmailTemplateWithUrl(otpCode, userName);
      
      const mailOptions = {
        from: {
          name: `${this.getFromName()} - Récupération de compte`,
          address: this.getFromEmail()
        },
        to: email,
        subject: '🔐 Code de récupération Velosi ERP (URL)',
        html: htmlTemplate,
        text: `Votre code de récupération Velosi ERP est: ${otpCode}. Ce code expire dans 10 minutes.`,
      };

      const result = await this.transporter.sendMail(mailOptions);
      this.logger.log(`Email OTP (URL publique) envoyé avec succès à ${email} - ID: ${result.messageId}`);
      return true;
    } catch (error) {
      this.logger.error(`Erreur envoi email OTP (URL publique) à ${email}:`, error);
      return false;
    }
  }

  /**
   * Template avec URL publique du logo
   */
  private getOtpEmailTemplateWithUrl(otpCode: string, userName?: string): string {
    const displayName = userName || 'Utilisateur';
    // Utiliser l'URL de production si FRONTEND_URL est définie, sinon localhost
    const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:4200';
    const logoUrl = frontendUrl.replace('4200', '3000') + '/assets/logo_societee.png'; // URL publique
    
    return `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Code de récupération Velosi ERP</title>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        </style>
    </head>
    <body style="font-family: 'Inter', Arial, sans-serif; background: #f0f0f0; padding: 20px; margin: 0;">
        <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 10px; padding: 30px;">
            <div style="text-align: center; margin-bottom: 30px;">
                <img src="${logoUrl}" alt="Logo Velosi" width="200" height="auto" style="display: block; margin: 0 auto;" />
                <h1 style="color: #333; margin: 20px 0;">🔐 Code de Récupération</h1>
                <p style="color: #666;">Récupération sécurisée de votre compte ERP</p>
            </div>
            
            <div style="padding: 20px;">
                <p>Bonjour <strong>${displayName}</strong>,</p>
                <p>Vous avez demandé la récupération de votre mot de passe pour votre compte <strong>Velosi ERP</strong>.</p>
                
                <div style="text-align: center; margin: 30px 0; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                    <p style="margin-bottom: 10px;">Votre code de vérification :</p>
                    <div style="font-size: 36px; font-weight: bold; color: #5e72e4; padding: 15px; background: white; border-radius: 8px; display: inline-block; letter-spacing: 4px;">
                        ${otpCode}
                    </div>
                    <p style="color: #e53e3e; margin-top: 15px; font-size: 14px;">
                        ⏰ Ce code expire dans 10 minutes
                    </p>
                </div>
                
                <p style="margin-top: 20px; color: #666;">
                    Si vous n'avez pas demandé cette récupération, ignorez cet email.
                </p>
            </div>
            
            ${this.getSimpleEmailFooter()}
        </div>
    </body>
    </html>
    `;
  }

  /**
   * 🏢 MULTI-TENANT: Envoyer les informations de connexion au nouveau personnel
   */
  async sendPersonnelCredentialsEmail(
    email: string, 
    userName: string, 
    password: string, 
    fullName: string,
    role: string,
    organisationId?: number
  ): Promise<boolean> {
    try {
      // Obtenir le transporter approprié
      const transporter = await this.getTransporterForOrganisation(organisationId);
      
      if (!transporter) {
        this.logger.warn(`⚠️ Impossible d'envoyer l'email à ${email}: Service email non configuré`);
        return false;
      }
      
      const organisation = organisationId ? await this.getOrganisation(organisationId) : null;
      const footer = await this.getEmailFooter(organisationId);
      const logoBase64 = await this.getOrganisationLogoBase64(organisationId);
      
      const htmlTemplate = await this.getPersonnelCredentialsTemplate(
        userName, 
        password, 
        fullName, 
        role, 
        organisation, 
        footer,
        logoBase64
      );
      
      const fromName = organisation?.smtp_from_name || organisation?.nom_affichage || organisation?.nom || this.getFromName();
      const fromEmail = organisation?.smtp_from_email || this.getFromEmail();
      const orgName = organisation?.nom_affichage || organisation?.nom || 'Shipnology ERP';
      
      // Préparer les pièces jointes
      const attachments = [];
      
      if (organisation?.logo_url && !organisation.logo_url.startsWith('http')) {
        const logoPath = path.isAbsolute(organisation.logo_url) 
          ? organisation.logo_url 
          : path.join(process.cwd(), 'uploads', organisation.logo_url);
        
        if (fs.existsSync(logoPath)) {
          attachments.push({
            filename: path.basename(logoPath),
            path: logoPath,
            cid: 'logo_organisation'
          });
        }
      } else if (!organisation) {
        const logoPath = this.getLogoPath();
        if (logoPath && fs.existsSync(logoPath)) {
          attachments.push({
            filename: 'logo_velosi.png',
            path: logoPath,
            cid: 'logo_velosi'
          });
        }
      }
      
      const mailOptions = {
        from: {
          name: `${fromName} - Bienvenue`,
          address: fromEmail
        },
        to: email,
        subject: `🎉 Bienvenue dans ${orgName} - Vos informations de connexion`,
        html: htmlTemplate,
        text: `Bienvenue ${fullName}! Vos informations de connexion ${orgName}: Nom d'utilisateur: ${userName}, Mot de passe: ${password}. Veuillez changer votre mot de passe lors de votre première connexion.`,
        attachments: attachments
      };

      const result = await transporter.sendMail(mailOptions);
      this.logger.log(`✅ Email informations personnel envoyé à ${email} (Org: ${organisation?.nom || 'Global'}) - ID: ${result.messageId}`);
      return true;
    } catch (error) {
      this.logger.error(`❌ Erreur envoi email informations personnel à ${email}:`, error);
      return false;
    }
  }

  /**
   * 🏢 MULTI-TENANT: Template HTML pour les informations de connexion du personnel
   */
  private async getPersonnelCredentialsTemplate(
    userName: string, 
    password: string, 
    fullName: string, 
    role: string,
    organisation?: Organisation | null,
    footer?: string,
    logoBase64?: string
  ): Promise<string> {
    const roleDisplayNames = {
      'commercial': 'Commercial',
      'admin': 'Administrateur',
      'manager': 'Manager',
      'employe': 'Employé'
    };
    
    const displayRole = roleDisplayNames[role] || role;
    const orgName = organisation?.nom_affichage || organisation?.nom || 'Shipnology ERP';
    const logoCid = organisation?.logo_url ? 'logo_organisation' : 'logo_velosi';
    const finalFooter = footer || await this.getEmailFooter(organisation?.id);
    
    return `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bienvenue dans ${orgName}</title>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
            
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Inter', Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
                padding: 20px;
            }
            
            .container {
                max-width: 650px;
                margin: 0 auto;
                background: #ffffff;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.15);
                overflow: hidden;
            }
            
            .header {
                background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
                padding: 40px 30px;
                text-align: center;
                color: white;
                position: relative;
            }
            
            .header::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" fill="rgba(255,255,255,0.1)"><polygon points="0,100 0,0 500,100 1000,0 1000,100"/></svg>');
                background-size: cover;
            }
            
            .header h1 {
                font-size: 32px;
                font-weight: 700;
                margin-bottom: 10px;
                position: relative;
                z-index: 2;
            }
            
            .header p {
                font-size: 18px;
                opacity: 0.95;
                position: relative;
                z-index: 2;
            }
            
            .welcome-icon {
                width: 80px;
                height: 80px;
                background: rgba(255, 255, 255, 0.2);
                border-radius: 50%;
                margin: 0 auto 20px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 40px;
                position: relative;
                z-index: 2;
            }
            
            .content {
                padding: 40px 30px;
            }
            
            .greeting {
                text-align: center;
                margin-bottom: 35px;
            }
            
            .greeting h2 {
                font-size: 28px;
                color: #1a202c;
                margin-bottom: 10px;
                font-weight: 600;
            }
            
            .greeting p {
                font-size: 16px;
                color: #4a5568;
                margin-bottom: 8px;
            }
            
            .role-badge {
                display: inline-block;
                background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
                color: white;
                padding: 8px 20px;
                border-radius: 25px;
                font-weight: 600;
                font-size: 14px;
                margin-top: 10px;
            }
            
            .credentials-section {
                background: linear-gradient(135deg, #f8fafc 0%, #edf2f7 100%);
                border: 2px solid #e2e8f0;
                border-radius: 16px;
                padding: 30px;
                margin: 30px 0;
                position: relative;
            }
            
            .credentials-title {
                text-align: center;
                font-size: 20px;
                font-weight: 600;
                color: #2d3748;
                margin-bottom: 25px;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
            }
            
            .credential-item {
                margin-bottom: 20px;
                padding: 20px;
                background: white;
                border-radius: 12px;
                border: 1px solid #e2e8f0;
                box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            }
            
            .credential-label {
                font-size: 14px;
                color: #4a5568;
                font-weight: 500;
                margin-bottom: 8px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }
            
            .credential-value {
                font-size: 18px;
                font-weight: 700;
                color: #2d3748;
                background: #f7fafc;
                padding: 12px 16px;
                border-radius: 8px;
                border: 2px dashed #cbd5e0;
                font-family: 'Courier New', monospace;
                word-break: break-all;
            }
            
            .security-alert {
                background: linear-gradient(135deg, #fed7d7 0%, #feb2b2 100%);
                border: 2px solid #fc8181;
                border-radius: 12px;
                padding: 25px;
                margin: 30px 0;
                position: relative;
            }
            
            .security-alert::before {
                content: '🔒';
                position: absolute;
                top: -15px;
                left: 50%;
                transform: translateX(-50%);
                background: #e53e3e;
                color: white;
                width: 30px;
                height: 30px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 16px;
            }
            
            .security-alert h3 {
                color: #c53030;
                font-size: 18px;
                margin-bottom: 15px;
                text-align: center;
                font-weight: 600;
            }
            
            .security-alert ul {
                color: #2d3748;
                margin-left: 20px;
            }
            
            .security-alert li {
                margin-bottom: 8px;
                font-size: 14px;
                font-weight: 500;
            }
            
            .instructions {
                background: linear-gradient(135deg, #e6fffa 0%, #b2f5ea 100%);
                border: 2px solid #4fd1c7;
                border-radius: 12px;
                padding: 25px;
                margin: 25px 0;
            }
            
            .instructions h3 {
                color: #234e52;
                font-size: 18px;
                margin-bottom: 15px;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .instructions ol {
                margin-left: 20px;
                color: #2d3748;
            }
            
            .instructions li {
                margin-bottom: 10px;
                font-size: 14px;
                font-weight: 500;
            }
            
            .contact-section {
                background: #f8f9fa;
                border-radius: 12px;
                padding: 25px;
                margin: 30px 0;
                text-align: center;
            }
            
            .contact-section h3 {
                color: #2d3748;
                font-size: 18px;
                margin-bottom: 15px;
            }
            
            .contact-section p {
                color: #4a5568;
                font-size: 14px;
                margin-bottom: 8px;
            }
            
            .footer {
                
                padding: 30px;
                text-align: center;
                color: white;
            }
            
            .footer p {
                margin-bottom: 8px;
                opacity: 0.9;
            }
            
            .footer .company-info {
                font-size: 14px;
                font-weight: 600;
                margin-top: 15px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <img src="cid:${logoCid}" alt="Logo ${orgName}" width="200" height="auto" />
              
                <h1>Bienvenue dans ${orgName} !</h1>
                <p>Votre compte a été créé avec succès</p>
            </div>
            
            <div class="content">
                <div class="greeting">
                    <h2>Bonjour ${fullName} !</h2>
                    <p>Nous sommes ravis de vous accueillir dans l'équipe ${orgName}.</p>
                    <p>Votre compte a été créé en tant que :</p>
                    <div class="role-badge">${displayRole}</div>
                </div>
                
                <div class="credentials-section">
                    <div class="credentials-title">
                        🔑 Vos informations de connexion
                    </div>
                    
                    <div class="credential-item">
                        <div class="credential-label">Nom d'utilisateur</div>
                        <div class="credential-value">${userName}</div>
                    </div>
                    
                    <div class="credential-item">
                        <div class="credential-label">Mot de passe temporaire</div>
                        <div class="credential-value">${password}</div>
                    </div>
                </div>
                
                <div class="security-alert">
                    <h3>🚨 IMPORTANT - Sécurité</h3>
                    <ul>
                        <li><strong>Changez immédiatement votre mot de passe</strong> lors de votre première connexion</li>
                        <li>Ne partagez jamais vos informations de connexion</li>
                        <li>Utilisez un mot de passe fort (min. 8 caractères, majuscules, minuscules, chiffres)</li>
                        <li>Déconnectez-vous toujours en fin de session</li>
                    </ul>
                </div>
                
                <div class="instructions">
                    <h3>📋 Première connexion</h3>
                    <ol>
                        <li>Rendez-vous sur le portail ${orgName}</li>
                        <li>Utilisez les informations ci-dessus pour vous connecter</li>
                        <li>Le système vous demandera de changer votre mot de passe</li>
                        <li>Complétez votre profil si nécessaire</li>
                        <li>Explorez votre nouvel environnement de travail !</li>
                    </ol>
                </div>
                
                <div class="contact-section">
                    <h3>💬 Besoin d'aide ?</h3>
                    <p><strong>Support ${orgName}</strong></p>
                    ${organisation?.email_service_technique ? `<p>📧 Email: ${organisation.email_service_technique}</p>` : ''}
                    ${organisation?.tel1 ? `<p>📞 Téléphone: ${organisation.tel1}</p>` : ''}
                    <p>🕒 Disponible du lundi au vendredi, 8h30 - 18h00</p>
                </div>
            </div>
            
            ${finalFooter}
        </div>
    </body>
    </html>
    `;
  }

  /**
   * Envoyer notification de désactivation/suspension
   */
  async sendPersonnelDeactivationEmail(
    email: string, 
    fullName: string, 
    action: 'desactive' | 'suspendu', 
    reason: string
  ): Promise<boolean> {
    try {
      const htmlTemplate = this.getDeactivationEmailTemplate(fullName, action, reason);
      
      // Préparer l'attachment du logo
      const logoPath = this.getLogoPath();
      const attachments = [];
      
      if (logoPath && fs.existsSync(logoPath)) {
        attachments.push({
          filename: 'logo_velosi.png',
          path: logoPath,
          cid: 'logo_velosi'
        });
      }
      
      const actionText = action === 'desactive' ? 'désactivé' : 'suspendu';
      
      const mailOptions = {
        from: {
          name: `${this.getFromName()} - Gestion RH`,
          address: this.getFromEmail()
        },
        to: email,
        subject: `⚠️ Compte ${actionText} - ${this.getFromName()}`,
        html: htmlTemplate,
        text: `Votre compte Velosi ERP a été ${actionText}. Raison: ${reason}. Contactez votre administrateur pour plus d'informations.`,
        attachments: attachments
      };

      const result = await this.transporter.sendMail(mailOptions);
      this.logger.log(`Email de ${action} envoyé avec succès à ${email} - ID: ${result.messageId}`);
      return true;
    } catch (error) {
      this.logger.error(`Erreur envoi email ${action} à ${email}:`, error);
      return false;
    }
  }

  /**
   * Envoyer notification de réactivation
   */
  async sendPersonnelReactivationEmail(
    email: string, 
    fullName: string
  ): Promise<boolean> {
    try {
      const htmlTemplate = this.getReactivationEmailTemplate(fullName);
      
      // Préparer l'attachment du logo
      const logoPath = this.getLogoPath();
      const attachments = [];
      
      if (logoPath && fs.existsSync(logoPath)) {
        attachments.push({
          filename: 'logo_velosi.png',
          path: logoPath,
          cid: 'logo_velosi'
        });
      }
      
      const mailOptions = {
        from: {
          name: `${this.getFromName()} - Gestion RH`,
          address: this.getFromEmail()
        },
        to: email,
        subject: `✅ Compte réactivé - ${this.getFromName()}`,
        html: htmlTemplate,
        text: `Bonne nouvelle ! Votre compte Velosi ERP a été réactivé. Vous pouvez maintenant vous reconnecter normalement.`,
        attachments: attachments
      };

      const result = await this.transporter.sendMail(mailOptions);
      this.logger.log(`Email de réactivation envoyé avec succès à ${email} - ID: ${result.messageId}`);
      return true;
    } catch (error) {
      this.logger.error(`Erreur envoi email réactivation à ${email}:`, error);
      return false;
    }
  }

  /**
   * Template HTML pour la désactivation/suspension
   */
  private getDeactivationEmailTemplate(
    fullName: string, 
    action: 'desactive' | 'suspendu', 
    reason: string
  ): string {
    const actionText = action === 'desactive' ? 'désactivé' : 'suspendu';
    const actionColor = action === 'desactive' ? '#e53e3e' : '#d69e2e';
    const actionIcon = action === 'desactive' ? '🚫' : '⏸️';
    
    return `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Compte ${actionText} - Velosi ERP</title>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
            
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Inter', Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                background: linear-gradient(135deg, ${actionColor} 0%, #2d3748 100%);
                padding: 20px;
            }
            
            .container {
                max-width: 650px;
                margin: 0 auto;
                background: #ffffff;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.15);
                overflow: hidden;
            }
            
            .header {
                background: linear-gradient(135deg, ${actionColor} 0%, #2d3748 100%);
                padding: 40px 30px;
                text-align: center;
                color: white;
                position: relative;
            }
            
            .header h1 {
                font-size: 32px;
                font-weight: 700;
                margin-bottom: 10px;
                position: relative;
                z-index: 2;
            }
            
            .header p {
                font-size: 18px;
                opacity: 0.95;
                position: relative;
                z-index: 2;
            }
            
            .status-icon {
                width: 80px;
                height: 80px;
                background: rgba(255, 255, 255, 0.2);
                border-radius: 50%;
                margin: 0 auto 20px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 40px;
                position: relative;
                z-index: 2;
            }
            
            .content {
                padding: 40px 30px;
            }
            
            .notification {
                text-align: center;
                margin-bottom: 35px;
            }
            
            .notification h2 {
                font-size: 28px;
                color: #1a202c;
                margin-bottom: 15px;
                font-weight: 600;
            }
            
            .notification p {
                font-size: 16px;
                color: #4a5568;
                margin-bottom: 8px;
            }
            
            .status-badge {
                display: inline-block;
                background: ${actionColor};
                color: white;
                padding: 10px 25px;
                border-radius: 25px;
                font-weight: 600;
                font-size: 16px;
                margin-top: 15px;
                text-transform: uppercase;
            }
            
            .reason-section {
                background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%);
                border: 2px solid #e2e8f0;
                border-radius: 16px;
                padding: 30px;
                margin: 30px 0;
            }
            
            .reason-title {
                font-size: 18px;
                font-weight: 600;
                color: #2d3748;
                margin-bottom: 15px;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .reason-text {
                background: white;
                padding: 20px;
                border-radius: 12px;
                border: 1px solid #e2e8f0;
                font-size: 16px;
                line-height: 1.6;
                color: #2d3748;
                box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            }
            
            .admin-info {
                background: #f8f9fa;
                border-radius: 12px;
                padding: 20px;
                margin: 25px 0;
                text-align: center;
            }
            
            .admin-info p {
                color: #4a5568;
                font-size: 14px;
                margin-bottom: 5px;
            }
            
            .contact-section {
                background: linear-gradient(135deg, #e6fffa 0%, #b2f5ea 100%);
                border: 2px solid #4fd1c7;
                border-radius: 12px;
                padding: 25px;
                margin: 25px 0;
                text-align: center;
            }
            
            .contact-section h3 {
                color: #234e52;
                font-size: 18px;
                margin-bottom: 15px;
            }
            
            .contact-section p {
                color: #2d3748;
                font-size: 14px;
                margin-bottom: 8px;
            }
            
            .footer {
                background: #f8f9fa;
                padding: 30px;
                text-align: center;
                color: #6c757d;
            }
            
            .footer p {
                margin-bottom: 8px;
                opacity: 0.9;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <img src="cid:logo_velosi" alt="Logo Velosi" width="200" height="auto" />
             
                <h1>Compte ${actionText}</h1>
                <p>Notification importante concernant votre accès</p>
            </div>
            
            <div class="content">
                <div class="notification">
                    <h2>Bonjour ${fullName}</h2>
                    <p>Nous vous informons que votre compte Velosi ERP a été ${actionText}.</p>
                    <div class="status-badge">Compte ${actionText}</div>
                </div>
                
                <div class="reason-section">
                    <div class="reason-title">
                        📝 Motif de cette action
                    </div>
                    <div class="reason-text">
                        ${reason}
                    </div>
                </div>
                
                <div class="admin-info">
                    <p><strong>Date :</strong> ${new Date().toLocaleDateString('fr-FR')} à ${new Date().toLocaleTimeString('fr-FR')}</p>
                </div>
                
                <div class="contact-section">
                    <h3>💬 Besoin d'informations ?</h3>
                    <p><strong>Service RH Velosi</strong></p>
                    <p>📧 Email: rh@velosi.com</p>
                    <p>📞 Téléphone: +33 (0)1 23 45 67 89</p>
                    <p>🕒 Disponible du lundi au vendredi, 8h30 - 18h00</p>
                    <p style="margin-top: 15px; font-weight: 600;">
                        Pour toute question concernant cette décision, n'hésitez pas à nous contacter.
                    </p>
                </div>
            </div>
            
            ${this.getSimpleEmailFooter()}
        </div>
    </body>
    </html>
    `;
  }

  /**
   * Template HTML pour la réactivation
   */
  private getReactivationEmailTemplate(fullName: string): string {
    return `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Compte réactivé - Velosi ERP</title>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
            
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Inter', Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
                padding: 20px;
            }
            
            .container {
                max-width: 650px;
                margin: 0 auto;
                background: #ffffff;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.15);
                overflow: hidden;
            }
            
            .header {
                background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
                padding: 40px 30px;
                text-align: center;
                color: white;
                position: relative;
            }
            
            .header h1 {
                font-size: 32px;
                font-weight: 700;
                margin-bottom: 10px;
                position: relative;
                z-index: 2;
            }
            
            .header p {
                font-size: 18px;
                opacity: 0.95;
                position: relative;
                z-index: 2;
            }
            
            .success-icon {
                width: 80px;
                height: 80px;
                background: rgba(255, 255, 255, 0.2);
                border-radius: 50%;
                margin: 0 auto 20px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 40px;
                position: relative;
                z-index: 2;
                animation: bounce 2s infinite;
            }
            
            @keyframes bounce {
                0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
                40% { transform: translateY(-10px); }
                60% { transform: translateY(-5px); }
            }
            
            .content {
                padding: 40px 30px;
            }
            
            .notification {
                text-align: center;
                margin-bottom: 35px;
            }
            
            .notification h2 {
                font-size: 28px;
                color: #1a202c;
                margin-bottom: 15px;
                font-weight: 600;
            }
            
            .notification p {
                font-size: 16px;
                color: #4a5568;
                margin-bottom: 10px;
            }
            
            .status-badge {
                display: inline-block;
                background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
                color: white;
                padding: 12px 30px;
                border-radius: 25px;
                font-weight: 600;
                font-size: 16px;
                margin-top: 15px;
                text-transform: uppercase;
                box-shadow: 0 4px 15px rgba(72, 187, 120, 0.3);
            }
            
            .instructions {
                background: linear-gradient(135deg, #f0fff4 0%, #c6f6d5 100%);
                border: 2px solid #68d391;
                border-radius: 16px;
                padding: 30px;
                margin: 30px 0;
            }
            
            .instructions h3 {
                color: #22543d;
                font-size: 18px;
                margin-bottom: 15px;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .instructions ul {
                margin-left: 20px;
                color: #2d3748;
            }
            
            .instructions li {
                margin-bottom: 10px;
                font-size: 14px;
                font-weight: 500;
            }
            
            .admin-info {
                background: #f8f9fa;
                border-radius: 12px;
                padding: 20px;
                margin: 25px 0;
                text-align: center;
            }
            
            .admin-info p {
                color: #4a5568;
                font-size: 14px;
                margin-bottom: 5px;
            }
            
            .footer {
                background: #f8f9fa;
                padding: 30px;
                text-align: center;
                color: #6c757d;
            }
            
            .footer p {
                margin-bottom: 8px;
                opacity: 0.9;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <img src="cid:logo_velosi" alt="Logo Velosi" width="200" height="auto" />
                
                <h1>Compte Réactivé !</h1>
                <p>Bienvenue de retour dans l'équipe</p>
            </div>
            
            <div class="content">
                <div class="notification">
                    <h2>Excellente nouvelle ${fullName} !</h2>
                    <p>Votre compte Velosi ERP a été réactivé avec succès.</p>
                    <p>Vous pouvez maintenant accéder à nouveau à tous vos services.</p>
                    <div class="status-badge">✅ Compte Actif</div>
                </div>
                
                <div class="instructions">
                    <h3>🔑 Prochaines étapes</h3>
                    <ul>
                        <li>Vous pouvez vous connecter immédiatement avec vos identifiants habituels</li>
                        <li>Toutes vos données et configurations ont été préservées</li>
                        <li>En cas de problème de connexion, contactez le support IT</li>
                        <li>Nous vous recommandons de changer votre mot de passe par sécurité</li>
                    </ul>
                </div>
                
                <div class="admin-info">
                    <p><strong>Date :</strong> ${new Date().toLocaleDateString('fr-FR')} à ${new Date().toLocaleTimeString('fr-FR')}</p>
                </div>
                
                <div style="text-align: center; margin: 30px 0; padding: 20px; background: #e6fffa; border-radius: 12px;">
                    <h3 style="color: #234e52; margin-bottom: 10px;">🚀 Bon retour parmi nous !</h3>
                    <p style="color: #2d3748; font-size: 16px;">
                        L'équipe Velosi vous souhaite une excellente reprise.
                    </p>
                </div>
            </div>
            
            ${this.getSimpleEmailFooter()}
        </div>
    </body>
    </html>
    `;
  }

  /**
   * 🏢 MULTI-TENANT: Envoyer les informations de connexion au nouveau client
   */
  async sendClientCredentialsEmail(
    email: string, 
    userName: string, 
    password: string, 
    companyName: string,
    interlocuteur?: string,
    organisationId?: number
  ): Promise<boolean> {
    try {
      const transporter = await this.getTransporterForOrganisation(organisationId);
      
      if (!transporter) {
        this.logger.warn(`⚠️ Impossible d'envoyer l'email à ${email}: Service email non configuré`);
        return false;
      }
      
      const organisation = organisationId ? await this.getOrganisation(organisationId) : null;
      const footer = await this.getEmailFooter(organisationId);
      const logoBase64 = await this.getOrganisationLogoBase64(organisationId);
      
      const htmlTemplate = await this.getClientCredentialsTemplate(
        userName, 
        password, 
        companyName, 
        interlocuteur,
        organisation,
        footer,
        logoBase64
      );
      
      const fromName = organisation?.smtp_from_name || organisation?.nom_affichage || organisation?.nom || this.getFromName();
      const fromEmail = organisation?.smtp_from_email || this.getFromEmail();
      const orgName = organisation?.nom_affichage || organisation?.nom || 'Shipnology ERP';
      
      const attachments = [];
      
      if (organisation?.logo_url && !organisation.logo_url.startsWith('http')) {
        const logoPath = path.isAbsolute(organisation.logo_url) 
          ? organisation.logo_url 
          : path.join(process.cwd(), 'uploads', organisation.logo_url);
        
        if (fs.existsSync(logoPath)) {
          attachments.push({
            filename: path.basename(logoPath),
            path: logoPath,
            cid: 'logo_organisation'
          });
        }
      } else if (!organisation) {
        const logoPath = this.getLogoPath();
        if (logoPath && fs.existsSync(logoPath)) {
          attachments.push({
            filename: 'logo_velosi.png',
            path: logoPath,
            cid: 'logo_velosi'
          });
        }
      }
      
      const mailOptions = {
        from: {
          name: `${fromName} - Bienvenue Client`,
          address: fromEmail
        },
        to: email,
        subject: `🎉 Bienvenue chez ${orgName} - Accès client créé`,
        html: htmlTemplate,
        text: `Bienvenue ${companyName}! Votre accès client ${orgName} a été créé: Nom d'utilisateur: ${userName}, Mot de passe: ${password}. Veuillez changer votre mot de passe lors de votre première connexion.`,
        attachments: attachments
      };

      const result = await transporter.sendMail(mailOptions);
      this.logger.log(`✅ Email informations client envoyé à ${email} (Org: ${organisation?.nom || 'Global'}) - ID: ${result.messageId}`);
      return true;
    } catch (error) {
      this.logger.error(`❌ Erreur envoi email informations client à ${email}:`, error);
      return false;
    }
  }

  /**
   * 🏢 MULTI-TENANT: Template HTML pour les informations de connexion du client
   */
  private async getClientCredentialsTemplate(
    userName: string, 
    password: string, 
    companyName: string, 
    interlocuteur?: string,
    organisation?: Organisation | null,
    footer?: string,
    logoBase64?: string
  ): Promise<string> {
    const displayName = interlocuteur ? `${companyName} (${interlocuteur})` : companyName;
    const orgName = organisation?.nom_affichage || organisation?.nom || 'Shipnology ERP';
    const logoCid = organisation?.logo_url ? 'logo_organisation' : 'logo_velosi';
    const finalFooter = footer || await this.getEmailFooter(organisation?.id);
    
    return `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bienvenue chez Velosi ERP</title>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
            
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Inter', Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
                padding: 20px;
            }
            
            .container {
                max-width: 650px;
                margin: 0 auto;
                background: #ffffff;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.15);
                overflow: hidden;
            }
            
            .header {
                background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
                padding: 40px 30px;
                text-align: center;
                color: white;
                position: relative;
            }
            
            .header::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" fill="rgba(255,255,255,0.1)"><polygon points="0,100 0,0 500,100 1000,0 1000,100"/></svg>');
                background-size: cover;
            }
            
            .header h1 {
                font-size: 32px;
                font-weight: 700;
                margin-bottom: 10px;
                position: relative;
                z-index: 2;
            }
            
            .header p {
                font-size: 18px;
                opacity: 0.95;
                position: relative;
                z-index: 2;
            }
            
            .welcome-icon {
                width: 80px;
                height: 80px;
                background: rgba(255, 255, 255, 0.2);
                border-radius: 50%;
                margin: 0 auto 20px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 40px;
                position: relative;
                z-index: 2;
            }
            
            .content {
                padding: 40px 30px;
            }
            
            .greeting {
                text-align: center;
                margin-bottom: 35px;
            }
            
            .greeting h2 {
                font-size: 28px;
                color: #1a202c;
                margin-bottom: 10px;
                font-weight: 600;
            }
            
            .greeting p {
                font-size: 16px;
                color: #4a5568;
                margin-bottom: 8px;
            }
            
            .client-badge {
                display: inline-block;
                background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
                color: white;
                padding: 8px 20px;
                border-radius: 25px;
                font-weight: 600;
                font-size: 14px;
                margin-top: 10px;
            }
            
            .credentials-section {
                background: linear-gradient(135deg, #f8fafc 0%, #edf2f7 100%);
                border: 2px solid #e2e8f0;
                border-radius: 16px;
                padding: 30px;
                margin: 30px 0;
                position: relative;
            }
            
            .credentials-title {
                text-align: center;
                font-size: 20px;
                font-weight: 600;
                color: #2d3748;
                margin-bottom: 25px;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
            }
            
            .credential-item {
                margin-bottom: 20px;
                padding: 20px;
                background: white;
                border-radius: 12px;
                border: 1px solid #e2e8f0;
                box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            }
            
            .credential-label {
                font-size: 14px;
                color: #4a5568;
                font-weight: 500;
                margin-bottom: 8px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }
            
            .credential-value {
                font-size: 18px;
                font-weight: 700;
                color: #2d3748;
                background: #f7fafc;
                padding: 12px 16px;
                border-radius: 8px;
                border: 2px dashed #cbd5e0;
                font-family: 'Courier New', monospace;
                word-break: break-all;
            }
            
            .security-alert {
                background: linear-gradient(135deg, #fed7d7 0%, #feb2b2 100%);
                border: 2px solid #fc8181;
                border-radius: 12px;
                padding: 25px;
                margin: 30px 0;
                position: relative;
            }
            
            .security-alert::before {
                content: '🔒';
                position: absolute;
                top: -15px;
                left: 50%;
                transform: translateX(-50%);
                background: #e53e3e;
                color: white;
                width: 30px;
                height: 30px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 16px;
            }
            
            .security-alert h3 {
                color: #c53030;
                font-size: 18px;
                margin-bottom: 15px;
                text-align: center;
                font-weight: 600;
            }
            
            .security-alert ul {
                color: #2d3748;
                margin-left: 20px;
            }
            
            .security-alert li {
                margin-bottom: 8px;
                font-size: 14px;
                font-weight: 500;
            }
            
            .instructions {
                background: linear-gradient(135deg, #e6fffa 0%, #b2f5ea 100%);
                border: 2px solid #4fd1c7;
                border-radius: 12px;
                padding: 25px;
                margin: 25px 0;
            }
            
            .instructions h3 {
                color: #234e52;
                font-size: 18px;
                margin-bottom: 15px;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .instructions ol {
                margin-left: 20px;
                color: #2d3748;
            }
            
            .instructions li {
                margin-bottom: 10px;
                font-size: 14px;
                font-weight: 500;
            }
            
            .contact-section {
                background: #f8f9fa;
                border-radius: 12px;
                padding: 25px;
                margin: 30px 0;
                text-align: center;
            }
            
            .contact-section h3 {
                color: #2d3748;
                font-size: 18px;
                margin-bottom: 15px;
            }
            
            .contact-section p {
                color: #4a5568;
                font-size: 14px;
                margin-bottom: 8px;
            }
            
                .footer {
                background: #f8f9fa;
                padding: 30px;
                text-align: center;
                color: #6c757d;
            }
            
            .footer p {
                margin-bottom: 8px;
                opacity: 0.9;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <img src="cid:logo_velosi" alt="Logo Velosi" width="200" height="auto" />
             
                <h1>Bienvenue chez Velosi ERP !</h1>
                <p>Votre accès client a été créé avec succès</p>
            </div>
            
            <div class="content">
                <div class="greeting">
                    <h2>Bonjour ${displayName} !</h2>
                    <p>Nous sommes ravis de vous compter parmi nos clients.</p>
                    <p>Votre accès au portail client a été créé :</p>
                    <div class="client-badge">Client Velosi</div>
                </div>
                
                <div class="credentials-section">
                    <div class="credentials-title">
                        🔑 Vos informations de connexion
                    </div>
                    
                    <div class="credential-item">
                        <div class="credential-label">Nom d'utilisateur</div>
                        <div class="credential-value">${userName}</div>
                    </div>
                    
                    <div class="credential-item">
                        <div class="credential-label">Mot de passe temporaire</div>
                        <div class="credential-value">${password}</div>
                    </div>
                </div>
                
                <div class="security-alert">
                    <h3>🚨 IMPORTANT - Sécurité</h3>
                    <ul>
                        <li><strong>Changez immédiatement votre mot de passe</strong> lors de votre première connexion</li>
                        <li>Ne partagez jamais vos informations de connexion</li>
                        <li>Utilisez un mot de passe fort (min. 8 caractères, majuscules, minuscules, chiffres)</li>
                        <li>Déconnectez-vous toujours en fin de session</li>
                    </ul>
                </div>
                
                <div class="instructions">
                    <h3>📋 Première connexion</h3>
                    <ol>
                        <li>Rendez-vous sur le portail client Velosi ERP</li>
                        <li>Utilisez les informations ci-dessus pour vous connecter</li>
                        <li>Le système vous demandera de changer votre mot de passe</li>
                        <li>Complétez votre profil client si nécessaire</li>
                        <li>Découvrez tous nos services disponibles !</li>
                    </ol>
                </div>
            </div>
            
            ${this.getSimpleEmailFooter()}
        </div>
    </body>
    </html>
    `;
  }

  /**
   * Envoyer notification de désactivation/suspension client
   */
  async sendClientDeactivationEmail(
    email: string, 
    clientName: string, 
    action: 'desactive' | 'suspendu', 
    reason: string
  ): Promise<boolean> {
    try {
      const htmlTemplate = this.getClientDeactivationEmailTemplate(clientName, action, reason);
      
      // Préparer l'attachment du logo
      const logoPath = this.getLogoPath();
      const attachments = [];
      
      if (logoPath && fs.existsSync(logoPath)) {
        attachments.push({
          filename: 'logo_velosi.png',
          path: logoPath,
          cid: 'logo_velosi'
        });
      }
      
      const actionText = action === 'desactive' ? 'désactivé' : 'suspendu';
      
      const mailOptions = {
        from: {
          name: `${this.getFromName()} - Service Client`,
          address: this.getFromEmail()
        },
        to: email,
        subject: `⚠️ Compte client ${actionText} - ${this.getFromName()}`,
        html: htmlTemplate,
        text: `Votre compte client Velosi ERP a été ${actionText}. Raison: ${reason}. Contactez notre service client pour plus d'informations.`,
        attachments: attachments
      };

      const result = await this.transporter.sendMail(mailOptions);
      this.logger.log(`Email de ${action} client envoyé avec succès à ${email} - ID: ${result.messageId}`);
      return true;
    } catch (error) {
      this.logger.error(`Erreur envoi email ${action} client à ${email}:`, error);
      return false;
    }
  }

  /**
   * Envoyer notification de réactivation client
   */
  async sendClientReactivationEmail(
    email: string, 
    clientName: string
  ): Promise<boolean> {
    try {
      const htmlTemplate = this.getClientReactivationEmailTemplate(clientName);
      
      // Préparer l'attachment du logo
      const logoPath = this.getLogoPath();
      const attachments = [];
      
      if (logoPath && fs.existsSync(logoPath)) {
        attachments.push({
          filename: 'logo_velosi.png',
          path: logoPath,
          cid: 'logo_velosi'
        });
      }
      
      const mailOptions = {
        from: {
          name: `${this.getFromName()} - Service Client`,
          address: this.getFromEmail()
        },
        to: email,
        subject: `✅ Compte client réactivé - ${this.getFromName()}`,
        html: htmlTemplate,
        text: `Votre compte client Velosi ERP a été réactivé avec succès. Vous pouvez maintenant accéder à nos services normalement.`,
        attachments: attachments
      };

      const result = await this.transporter.sendMail(mailOptions);
      this.logger.log(`Email de réactivation client envoyé avec succès à ${email} - ID: ${result.messageId}`);
      return true;
    } catch (error) {
      this.logger.error(`Erreur envoi email réactivation client à ${email}:`, error);
      return false;
    }
  }

  /**
   * Template HTML pour email de désactivation/suspension client (identique au personnel)
   */
  private getClientDeactivationEmailTemplate(clientName: string, action: 'desactive' | 'suspendu', reason: string): string {
    const actionText = action === 'desactive' ? 'désactivé' : 'suspendu';
    const actionColor = action === 'desactive' ? '#e53e3e' : '#d69e2e';
    const actionIcon = action === 'desactive' ? '🚫' : '⏸️';
    
    return `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Compte ${actionText} - Velosi ERP</title>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
            
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Inter', Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                background: linear-gradient(135deg, ${actionColor} 0%, #2d3748 100%);
                padding: 20px;
            }
            
            .container {
                max-width: 650px;
                margin: 0 auto;
                background: #ffffff;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.15);
                overflow: hidden;
            }
            
            .header {
                background: linear-gradient(135deg, ${actionColor} 0%, #2d3748 100%);
                padding: 40px 30px;
                text-align: center;
                color: white;
                position: relative;
            }
            
            .header h1 {
                font-size: 32px;
                font-weight: 700;
                margin-bottom: 10px;
                position: relative;
                z-index: 2;
            }
            
            .header p {
                font-size: 16px;
                opacity: 0.9;
                position: relative;
                z-index: 2;
            }
            
            .content {
                padding: 40px 30px;
            }
            
            .status-badge {
                display: inline-flex;
                align-items: center;
                background: ${actionColor};
                color: white;
                padding: 12px 20px;
                border-radius: 25px;
                font-weight: 600;
                font-size: 16px;
                margin-bottom: 30px;
            }
            
            .info-card {
                background: #f8fafc;
                border: 1px solid #e2e8f0;
                border-radius: 12px;
                padding: 25px;
                margin: 25px 0;
            }
            
            .info-card h3 {
                color: #2d3748;
                font-size: 18px;
                font-weight: 600;
                margin-bottom: 15px;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            
            .detail-item {
                display: flex;
                justify-content: space-between;
                padding: 8px 0;
                border-bottom: 1px solid #e2e8f0;
            }
            
            .detail-item:last-child {
                border-bottom: none;
            }
            
            .detail-label {
                font-weight: 500;
                color: #4a5568;
            }
            
            .detail-value {
                color: #2d3748;
                font-weight: 600;
            }
            
            .contact-info {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 25px;
                border-radius: 12px;
                margin-top: 30px;
            }
            
            .contact-info h3 {
                color: white;
                margin-bottom: 15px;
            }
            
            .contact-info p {
                margin: 8px 0;
                opacity: 0.9;
            }
            
               .footer {
                background: #f8f9fa;
                padding: 30px;
                text-align: center;
                color: #6c757d;
            }
            
            .footer p {
                margin-bottom: 8px;
                opacity: 0.9;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <img src="cid:logo_velosi" alt="Logo Velosi" width="200" height="auto" />
             
                <h1>Compte ${actionText}</h1>
                <p>Notification importante concernant votre accès</p>
            </div>
            
            <div class="content">
                <div class="notification">
                    <h2>Bonjour ${clientName}</h2>
                    <p>Nous vous informons que votre compte client Velosi ERP a été ${actionText}.</p>
                    <div class="status-badge">Compte ${actionText}
                </div>
                
                <div class="reason-section">
                    <div class="reason-title">
                        📝 Motif de cette action
                    </div>
                    <div class="reason-text">
                        ${reason}
                    </div>
                </div>
                
                <div class="admin-info">
                    <p><strong>Date :</strong> ${new Date().toLocaleDateString('fr-FR')} à ${new Date().toLocaleTimeString('fr-FR')}</p>
                </div>

                
                <div class="contact-section">
                    <h3>� Besoin d'informations ?</h3>
                    <p><strong>Service Client Velosi</strong></p>
                    <p>📧 Email: service.client@velosi.com</p>
                    <p>📞 Téléphone: +33 (0)1 23 45 67 89</p>
                    <p>🕒 Disponible du lundi au vendredi, 8h30 - 18h00</p>
                    <p style="margin-top: 15px; font-weight: 600;">
                        Pour toute question concernant cette décision, n'hésitez pas à nous contacter.
                    </p>
                </div>
            </div>
            
            <div class="footer">
                <p><strong>Velosi ERP</strong></p>
                <p>&copy; 2024 Tous droits réservés.</p>
                <p>Ceci est un email automatique, merci de ne pas y répondre.</p>
            </div>
        </div>
    </body>
    </html>
    `;
  }

  /**
   * Template HTML pour email de réactivation client (identique au personnel)
   */
  private getClientReactivationEmailTemplate(clientName: string): string {
    const actionColor = '#38a169'; // Vert pour réactivation
    
    return `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Compte Réactivé - Velosi ERP</title>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
            
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Inter', Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                background: linear-gradient(135deg, ${actionColor} 0%, #2d3748 100%);
                padding: 20px;
            }
            
            .container {
                max-width: 650px;
                margin: 0 auto;
                background: #ffffff;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.15);
                overflow: hidden;
            }
            
            .header {
                background: linear-gradient(135deg, ${actionColor} 0%, #2d3748 100%);
                padding: 40px 30px;
                text-align: center;
                color: white;
                position: relative;
            }
            
            .header h1 {
                font-size: 32px;
                font-weight: 700;
                margin-bottom: 10px;
                position: relative;
                z-index: 2;
            }
            
            .header p {
                font-size: 16px;
                opacity: 0.9;
                position: relative;
                z-index: 2;
            }
            
            .content {
                padding: 40px 30px;
            }
            
            .status-badge {
                display: inline-flex;
                align-items: center;
                background: ${actionColor};
                color: white;
                padding: 12px 20px;
                border-radius: 25px;
                font-weight: 600;
                font-size: 16px;
                margin-bottom: 30px;
            }
            
            .info-card {
                background: #f8fafc;
                border: 1px solid #e2e8f0;
                border-radius: 12px;
                padding: 25px;
                margin: 25px 0;
            }
            
            .info-card h3 {
                color: #2d3748;
                font-size: 18px;
                font-weight: 600;
                margin-bottom: 15px;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            
            .detail-item {
                display: flex;
                justify-content: space-between;
                padding: 8px 0;
                border-bottom: 1px solid #e2e8f0;
            }
            
            .detail-item:last-child {
                border-bottom: none;
            }
            
            .detail-label {
                font-weight: 500;
                color: #4a5568;
            }
            
            .detail-value {
                color: #2d3748;
                font-weight: 600;
            }
            
            .contact-info {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 25px;
                border-radius: 12px;
                margin-top: 30px;
            }
            
            .contact-info h3 {
                color: white;
                margin-bottom: 15px;
            }
            
            .contact-info p {
                margin: 8px 0;
                opacity: 0.9;
            }
            
               .footer {
                background: #f8f9fa;
                padding: 30px;
                text-align: center;
                color: #6c757d;
            }
            
            .footer p {
                margin-bottom: 8px;
                opacity: 0.9;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <img src="cid:logo_velosi" alt="Logo Velosi" width="200" height="auto" />
                
                <h1>Compte Réactivé !</h1>
                <p>Bienvenue de retour dans l'équipe</p>
            </div>
            
            <div class="content">
                <div class="notification">
                    <h2>Excellente nouvelle ${clientName} !</h2>
                    <p>Votre compte client Velosi ERP a été réactivé avec succès.</p>
                    <p>Vous pouvez maintenant accéder à nouveau à tous vos services.</p>
                    <div class="status-badge">✅ Compte Actif</div>
                </div>
                
                <div class="info-card">
                    <h3>📋 Détails de la réactivation</h3>
                    <div class="detail-item">
                        <span class="detail-label">Action :</span>
                        <span class="detail-value">Réactivation du compte</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Statut :</span>
                        <span class="detail-value">Compte actif et opérationnel</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Date :</span>
                        <span class="detail-value">${new Date().toLocaleDateString('fr-FR', { 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}</span>
                    </div>
                </div>
                
                <div class="info-card" style="border-color: ${actionColor};">
                    <h3 style="color: ${actionColor};">🎉 Bienvenue de nouveau !</h3>
                    <p style="color: #4a5568;">Votre compte est maintenant pleinement opérationnel. Vous pouvez de nouveau accéder à tous les services Velosi ERP.</p>
                    <p style="color: #4a5568; margin-top: 10px;">Nous vous remercions de votre confiance et sommes ravis de vous accompagner à nouveau dans votre activité.</p>
                </div>
            </div>
            
            <div class="footer">
                <p><strong>Velosi ERP</strong> - Plateforme de Gestion Intégrée</p>
                <p>&copy; 2024 Velosi ERP. Tous droits réservés.</p>
                <p style="opacity: 0.7;">Ceci est un email automatique, merci de ne pas y répondre directement.</p>
            </div>
        </div>
    </body>
    </html>
    `;
  }

  /**
   * Envoyer un email de contact avec le template Velosi
   */
  async sendContactEmail(contactData: {
    firstName: string;
    lastName: string;
    phone?: string;
    email: string;
    enquiryType: string;
    message: string;
  }): Promise<boolean> {
    try {
      const fullName = `${contactData.firstName} ${contactData.lastName}`;
      const htmlTemplate = this.getContactEmailTemplate(contactData);
      
      // Obtenir le chemin du logo
      const logoPath = this.getLogoPath();
      
      // Configuration de l'email avec pièce jointe du logo si disponible
      const mailOptions: any = {
        from: this.configService.get<string>('EMAIL_FROM') || 'no-reply@velosi.com',
        to: this.getFromEmail(), // Recevoir les messages de contact sur l'email principal
        subject: `Nouveau message de contact - ${contactData.enquiryType}`,
        html: htmlTemplate,
        attachments: []
      };

      // Ajouter le logo comme pièce jointe si disponible
      if (logoPath) {
        mailOptions.attachments.push({
          filename: 'logo_velosi.png',
          path: logoPath,
          cid: 'logo_velosi' // Content-ID pour référencer dans le HTML
        });
      }

      await this.transporter.sendMail(mailOptions);
      this.logger.log(`✅ Email de contact envoyé avec succès à ${this.getFromEmail()} depuis ${contactData.email}`);
      return true;
    } catch (error) {
      this.logger.error('❌ Erreur lors de l\'envoi de l\'email de contact:', error);
      return false;
    }
  }

  /**
   * Template HTML pour l'email de contact
   */
  private getContactEmailTemplate(contactData: {
    firstName: string;
    lastName: string;
    phone?: string;
    email: string;
    enquiryType: string;
    message: string;
  }): string {
    const fullName = `${contactData.firstName} ${contactData.lastName}`;
    const phoneRow = contactData.phone ? `
                        <tr>
                            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0; font-weight: 600; color: #4a5568; width: 140px;">Téléphone :</td>
                            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0; color: #2d3748;">${contactData.phone}</td>
                        </tr>` : '';
    
    const enquiryTypeMap = {
      'general': 'Demande générale',
      'technical': 'Problème technique',
      'bug': 'Signalement de bug',
      'support': 'Demande d\'assistance',
      'feature': 'Demande de fonctionnalité'
    };
    
    const enquiryTypeLabel = enquiryTypeMap[contactData.enquiryType] || contactData.enquiryType;
    const isPriorityHigh = contactData.enquiryType === 'bug' || contactData.enquiryType === 'technical';
    
    return `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Nouveau message de contact - Velosi ERP</title>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
            
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Inter', Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                padding: 20px;
            }
            
            .container {
                max-width: 600px;
                margin: 0 auto;
                background: #ffffff;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                overflow: hidden;
            }
            
            .header {
                background: linear-gradient(135deg, ${isPriorityHigh ? '#e74c3c 0%, #c0392b 100%' : '#5e72e4 0%, #825ee4 100%'});
                padding: 40px 30px;
                text-align: center;
                color: white;
                position: relative;
            }
            
            .header::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" fill="rgba(255,255,255,0.1)"><polygon points="0,100 0,0 500,100 1000,0 1000,100"/></svg>');
                background-size: cover;
            }
            
            .logo {
                position: relative;
                z-index: 2;
                margin-bottom: 20px;
            }
            
            .logo-fallback {
                width: 200px;
                height: 100px;
                background: rgba(255,255,255,0.2);
                border-radius: 12px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                font-size: 24px;
                font-weight: bold;
                color: #fff;
                margin-bottom: 20px;
                z-index: 2;
                position: relative;
            }
            
            .header h1 {
                font-size: 28px;
                font-weight: 700;
                margin: 0;
                position: relative;
                z-index: 2;
            }
            
            .header p {
                font-size: 16px;
                opacity: 0.9;
                position: relative;
                z-index: 2;
                margin-top: 8px;
            }
            
            .content {
                padding: 40px 30px;
            }
            
            .greeting {
                font-size: 18px;
                margin-bottom: 25px;
                color: #2d3748;
                font-weight: 500;
            }
            
            .contact-section {
                background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%);
                border-radius: 16px;
                padding: 30px;
                margin-bottom: 30px;
                border: 2px solid #e2e8f0;
                position: relative;
            }
            
            .contact-section::before {
                content: '👤';
                position: absolute;
                top: -15px;
                left: 25px;
                background: #fff;
                width: 40px;
                height: 40px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 18px;
                border: 2px solid #e2e8f0;
            }
            
            .section-title {
                font-size: 20px;
                color: #2d3748;
                margin-bottom: 20px;
                font-weight: 600;
            }
            
            .info-table {
                width: 100%;
                border-collapse: collapse;
            }
            
            .info-table td {
                padding: 12px 0;
                border-bottom: 1px solid #e2e8f0;
            }
            
            .info-table td:first-child {
                font-weight: 600;
                color: #4a5568;
                width: 140px;
            }
            
            .info-table td:last-child {
                color: #2d3748;
            }
            
            .priority-badge {
                display: inline-block;
                padding: 6px 16px;
                border-radius: 20px;
                font-size: 12px;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.5px;
                background: ${isPriorityHigh ? 'linear-gradient(135deg, #e74c3c 0%, #c0392b 100%)' : 'linear-gradient(135deg, #5e72e4 0%, #825ee4 100%)'};
                color: #fff;
                box-shadow: 0 4px 12px ${isPriorityHigh ? 'rgba(231, 76, 60, 0.3)' : 'rgba(94, 114, 228, 0.3)'};
            }
            
            .message-section {
                background: linear-gradient(135deg, #fff5f5 0%, #fed7d7 100%);
                border-radius: 16px;
                padding: 30px;
                margin-bottom: 30px;
                border: 2px solid #feb2b2;
                position: relative;
            }
            
            .message-section::before {
                content: '💬';
                position: absolute;
                top: -15px;
                left: 25px;
                background: #fff;
                width: 40px;
                height: 40px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 18px;
                border: 2px solid #feb2b2;
            }
            
            .message-content {
                background: #fff;
                padding: 25px;
                border-radius: 12px;
                color: #2d3748;
                line-height: 1.8;
                white-space: pre-wrap;
                border: 1px solid #e2e8f0;
                box-shadow: 0 4px 6px rgba(0,0,0,0.05);
                font-size: 15px;
            }
            
            .actions-section {
                background: linear-gradient(135deg, #f0fff4 0%, #c6f6d5 100%);
                border-radius: 16px;
                padding: 25px;
                margin-bottom: 30px;
                border: 2px solid #9ae6b4;
                text-align: center;
            }
            
            .action-button {
                display: inline-block;
                background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
                color: #fff;
                padding: 12px 30px;
                border-radius: 25px;
                text-decoration: none;
                font-weight: 600;
                font-size: 14px;
                box-shadow: 0 4px 15px rgba(72, 187, 120, 0.3);
                transition: all 0.3s ease;
                margin: 5px 10px;
            }
            
            .footer {
                background: linear-gradient(135deg, #2d3748 0%, #1a202c 100%);
                color: #e2e8f0;
                padding: 30px;
                text-align: center;
                font-size: 14px;
            }
            
            .system-info {
                background: rgba(255,255,255,0.1);
                padding: 20px;
                border-radius: 12px;
                margin-bottom: 20px;
                border: 1px solid rgba(255,255,255,0.2);
            }
            
            .timestamp {
                color: #a0aec0;
                font-size: 13px;
                margin-top: 10px;
                font-weight: 500;
            }
            
            .divider {
                height: 2px;
                background: linear-gradient(90deg, transparent, #e2e8f0, transparent);
                margin: 25px 0;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                
                <h1>${isPriorityHigh ? '🚨 ' : '📧 '}Nouveau Message de Contact</h1>
                <p>Demande reçue depuis le système ERP Velosi</p>
            </div>
            
            <div class="content">
                <div class="greeting">
                    Bonjour l'équipe Velosi,<br>
                    Vous avez reçu ${isPriorityHigh ? 'une demande prioritaire' : 'un nouveau message'} depuis le formulaire de contact.
                </div>
                
                <div class="contact-section">
                    <h2 class="section-title">Informations du contact</h2>
                    <table class="info-table">
                        <tr>
                            <td>Nom complet :</td>
                            <td><strong>${fullName}</strong></td>
                        </tr>
                        <tr>
                            <td>Email :</td>
                            <td><a href="mailto:${contactData.email}" style="color: #5e72e4; text-decoration: none; font-weight: 500;">${contactData.email}</a></td>
                        </tr>
                        ${phoneRow}
                        <tr>
                            <td>Type de demande :</td>
                            <td><span class="priority-badge">${enquiryTypeLabel}</span></td>
                        </tr>
                    </table>
                </div>
                
                <div class="divider"></div>
                
                <div class="message-section">
                    <h2 class="section-title">Message reçu</h2>
                    <div class="message-content">${contactData.message}</div>
                </div>
                
                <div class="actions-section">
                    <h3 style="color: #2d3748; margin-bottom: 15px; font-size: 18px;">Actions recommandées</h3>
                    <a href="mailto:${contactData.email}?subject=Re: ${enquiryTypeLabel} - Velosi ERP" class="action-button">
                        📧 Répondre au client
                    </a>
                    ${isPriorityHigh ? '<a href="#" class="action-button" style="background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%); box-shadow: 0 4px 15px rgba(231, 76, 60, 0.3);">🚨 Traiter en priorité</a>' : ''}
                </div>
            </div>
            
            <div class="footer">
                <div class="system-info">
                    <strong>📧 Système de Contact ERP Velosi</strong>
                    <div class="timestamp">
                        Reçu le ${new Date().toLocaleDateString('fr-FR', { 
                          weekday: 'long',
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric', 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })}
                    </div>
                </div>
                <p style="margin: 15px 0 0 0; font-size: 12px; color: #a0aec0;">
                    Cet email a été généré automatiquement par le système ERP Velosi.<br>
                    Répondez directement à l'adresse email du client pour traiter sa demande.
                </p>
            </div>
        </div>
    </body>
    </html>
    `;
  }
}